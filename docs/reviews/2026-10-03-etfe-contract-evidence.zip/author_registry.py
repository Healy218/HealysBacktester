import hashlib
import inspect
import json
from pathlib import Path
import sys

root = Path('/home/healy/Coding/HealysBacktester')
sys.path.insert(0, str(root))
from nn_meta.tradingview_features import FEATURE_SPECS, SOURCE_MAP, feature_schema

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

old_path = root/'docs/specs/V7_MODEL_TRIALS_20260916.json'
old = json.loads(old_path.read_text())
tv = feature_schema(minimum_tick=.01, session_policy='local_research', vwap_mode='observed')
sources = ['nn_meta/tradingview_features.py', 'nn_meta/build_meta_dataset.py',
           'nn_meta/v7/features.py', 'nn_meta/v7/context.py', 'nn_meta/v7/setup.py',
           'nn_meta/v7/rows.py', 'nn_meta/v7/daily.py', 'nn_meta/v7/causal_prices.py',
           'nn_meta/v7/bars.py', 'nn_meta/multitimeframe_catalog.py',
           'indicators/tradingview_registry.py', 'nn_meta/weekly_expiry.py']
sources += [str(p.relative_to(root)) for p in (root/'v3').glob('*.py') if 'tv_' in p.name or 'pine' in p.name]
sources += [str(p.relative_to(root)) for p in (root/'indicators/tradingview_sources').glob('*.json')]
source_hashes = {name:sha(root/name) for name in sorted(set(sources))}
scopes = []
for alias, script_id, calc in SOURCE_MAP:
    scopes.append(dict(scope=alias, script_id=script_id,
        calculator=f'{calc.__module__}.{calc.__name__}',
        source_file=str(Path(inspect.getfile(calc)).relative_to(root)),
        parameters=tv['parameters'][alias],
        window='Native rolling windows and recursive state in parameters/source; fixed history origin, no partition reset.',
        warmup='Native minimum-periods and ready/valid predicates; no fabricated initialized outputs; full closed-bar prefix.',
        overrides={'bar_minutes':'row signal timeframe', 'as_of':'signal close',
            'htf':'240/720/2D for 1/5/15; immutable calendar anchor',
            'setup':'nn_meta.v7.setup.setup_scanner; causal minute ORB and HLC3 session VWAP'},
        external_parity=False))
tech = {
'ma_gap':('(SMA_fast(C)-SMA_slow(C))/C; MA variant uses its fast/slow, otherwise 10/30','max(fast,slow) complete signal bars'),
'px_vs_fast':('C/SMA_fast(C)-1; MA variant fast, otherwise 10','fast complete signal bars'),
'rsi14':('(100-100/(1+EWM(max(delta C,0),alpha=1/14,adjust=False)/EWM(max(-delta C,0),alpha=1/14,adjust=False)))/100','recursive from history origin; zero loss denominator is missing'),
'macd_hist':('((EMA12(C)-EMA26(C))-EMA9(EMA12(C)-EMA26(C)))/C; adjust=False','recursive from history origin'),
'bb_z':('(C-SMA20(C))/(2*sample_std20(C))','20 complete signal bars'),
'session_gap':('first_session_open/previous_session_last_close-1','two consecutive observed regular sessions'),
'gap_abs_z':('(abs(session_gap)-mean(abs(gap),60 sessions))/sample_std(abs(gap),60 sessions); current known opening gap included','60 session gaps, no skipped calendar gaps'),
'tod':('(bar_open-session_open)/(session_close-session_open)','one complete signal bar; dated session bounds'),
'dow':('New_York_weekday/4, Monday=0','one complete signal bar'),
'is_first_hour':('float(bar_open-session_open < 60 minutes)','one complete signal bar'),
'is_last_hour':('float(session_close-bar_end < 60 minutes)','one complete signal bar'),
'dow_tod':('dow*tod','one complete signal bar')}
for n in (1,8,26): tech[f'ret_{n}']=(f'C/C.shift({n})-1; no fill across incomplete chart bins',f'{n+1} complete signal bars')
daily = {
'rvol_5':('rvol_5','sqrt(252)*sample_std(log(adjusted_daily_close).diff(),5)','6 consecutive session closes'),
'rvol_21':('rvol_21','sqrt(252)*sample_std(log(adjusted_daily_close).diff(),21)','22 consecutive session closes'),
'beta_60d':('beta_60d','sample_cov(simple_return,SPY_simple_return,60)/sample_var(SPY_simple_return,60)','61 consecutive paired session closes'),
'atm_iv_near':('etfe_bar_iv_near','median(BS_proxy_IV(last fresh minute VWAP),1<=DTE<=20,abs(log(K/S))<.01)','one fully captured prior-session surface'),
'atm_iv_far':('etfe_bar_iv_far','median(BS_proxy_IV(last fresh minute VWAP),21<=DTE<=45,abs(log(K/S))<.01)','one fully captured prior-session surface'),
'term_slope':('etfe_bar_iv_term_slope','etfe_bar_iv_far-etfe_bar_iv_near','one valid paired prior-session surface'),
'iv_chg_5':('etfe_bar_iv_change_5','etfe_bar_iv_near[d]-etfe_bar_iv_near[d-5 sessions]','six consecutive surface sessions'),
'pc_ratio':('etfe_bar_put_call_volume_ratio','clip(sum eligible put session volume/sum eligible call session volume,0,5); eligible 1-45DTE and fresh closing VWAP>=.20','one fully captured prior-session surface'),
'market_iv':('etfe_spy_bar_iv_near','SPY etfe_bar_iv_near from same prior session','one valid SPY prior-session surface'),
'rv_iv_spread':('etfe_rv_bar_iv_spread','rvol_21-etfe_bar_iv_near','22 consecutive closes and valid prior-session surface')}
tick = {
'opt_tick_spread_bps':('etfe_option_trade_range_bps','10000*(max(trade_price)-min(trade_price))/trade_VWAP; dispersion, not spread'),
'opt_tick_size_imbalance':('etfe_option_trade_size_cv','population_std(trade_size)/mean(trade_size); dispersion, not resting size'),
'opt_tick_valid_quote_fraction':('etfe_option_traded_bar_fraction','number of valid positive-volume/count 1Min bars / m expected bins'),
'opt_tick_quote_age_seconds':('etfe_option_bar_end_age_seconds','(decision-last available positive traded bar end) seconds within window'),
'opt_tick_quote_updates_per_second':('etfe_option_traded_bars_per_second','number of valid traded 1Min bars/(60*m)'),
'opt_tick_trade_count_per_second':('etfe_option_trade_count_per_second','eligible trade count/(60*m)'),
'opt_tick_trade_volume_per_second':('etfe_option_trade_volume_per_second','sum eligible trade contracts/(60*m)'),
'opt_tick_trade_vwap_mid_bps':('etfe_option_vwap_last_bps','10000*(sum(price*size)/sum(size)-last eligible trade price)/last eligible trade price'),
'opt_tick_signed_volume_fraction':('etfe_option_tickrule_signed_volume_fraction','sum(tick_rule_sign*size)/sum(all eligible size); unclassified sign=0'),
'opt_tick_classified_volume_fraction':('etfe_option_tickrule_classified_volume_fraction','sum(size where tick-rule sign nonzero)/sum(all eligible size)')}
specs = {s.name:s for s in FEATURE_SPECS}
fields=[]
for name in old['feature_columns']:
    f=dict(inherited_name=name,name=name,disposition='retained',dtype='float64_nullable',
           available_at='signal_close', window='decision metadata',warmup='none',
           source='frozen ETFE catalog and dated proposal identity',
           missingness='Missing required identity blocks row; structural absent parameter is NaN with mask.')
    if name in tech:
        f.update(disposition='recomputed',formula=tech[name][0],window=tech[name][1],warmup=tech[name][1],
          source='Alpaca raw SIP 1Min bars; dated causal actions; session aggregation',
          missingness='NaN for native warmup/zero denominator; missing captures block admission.')
    elif name in daily:
        dest, formula, window=daily[name]
        f.update(name=dest,disposition='replaced' if dest!=name else 'recomputed',formula=formula,
          window=window,warmup=window,available_at='next regular session open, later than all source availability',
          source='Alpaca raw SIP stock bars + dated actions; Alpaca OPRA option 1Min VWAP/volume and dated contract census',
          missingness='No forward fill. Natural no-ATM/zero denominator is NaN; missing capture/reference blocks admission.')
    elif name in specs:
        s=specs[name]
        expression={'price_atr':f'({s.source}.{s.field}-Close)/Wilder_ATR14',
          'range_atr':f'{s.source}.{s.field}/Wilder_ATR14', 'percent':f'{s.source}.{s.field}/100',
          'phase':f'map({s.source}.{s.field},idle=0,accum=1,sweepPending=2,manip=3,dist=4)'}.get(s.transform,f'float({s.source}.{s.field})')
        f.update(disposition='recomputed',formula=expression,source=f'tv_scopes.{s.source}; source-bound native field {s.field}',
          window=f'tv_scopes.{s.source}.parameters and pinned calculator recurrence',
          warmup=f'tv_scopes.{s.source}.warmup; ATR14 readiness where normalized',valid_when=s.valid_when,
          missingness='NaN until native readiness/valid_when; zero ATR invalid; probability reference needs resolved same-side history; source gaps block admission.')
    elif name in tick:
        dest, formula=tick[name]
        f.update(name=dest,disposition='replaced',formula=formula,
          source='Alpaca historical option trades/1Min bars for preselected dated contract',
          window='m aligned 1Min bins [signal_close-(m+1)min,signal_close-1min); source availability<=signal_close',
          warmup='complete same-session window; at least one trade for price ratios; first/leading-equal trades remain unclassified',
          missingness='Complete empty: count/volume/bar-rate=0; undefined ratios NaN. Uncaptured/ambiguous order is missing, never invented quote fields.')
    elif name.startswith('strat_'):
        f['formula']=f'float(strategy == {name[6:]!r})'
    elif name.startswith('sec_'):
        f.update(formula=f'float(dated_sector == {name[4:]!r}); SPY/QQQ/VOO idx_etf',source='dated ETF identities and pinned sector taxonomy')
    elif name.startswith('timeframe_'):
        if name=='timeframe_30': f.update(name='timeframe_1',disposition='replaced')
        f['formula']=f'float(signal_minutes == {f["name"][10:]})'
    elif name.startswith('param_setup_'):
        f['formula']=f'float(setup_identity == {name[12:]!r})'
    elif name.startswith('param_'):
        f['formula']=f'float(variant.params[{name[6:]!r}]); NaN when structurally absent'
    elif name=='dir_short': f['formula']='float(option_right == P)'
    elif name=='dte_frac': f['formula']='actual_calendar_DTE_at_decision/9'
    elif name=='moneyness': f['formula']='log(dated_selected_strike/causal_raw_spot)'
    elif name=='bars_since_signal': f['formula']='log1p(number of completed signal bars since previous same-variant/direction signal); first signal missing'
    else: raise ValueError(name)
    fields.append(f)
result=dict(schema='etfe-trade-bar-features-v1',status='declared_not_implemented_or_admitted',
  inherited_schema_file=str(old_path.relative_to(root)),inherited_schema_sha256=sha(old_path),
  inherited_field_count=len(fields),value_field_count=len(fields),model_input_count=2*len(fields),
  model_order=[f['name'] for f in fields]+['missing__'+f['name'] for f in fields],
  missing_indicator=dict(dtype='uint8',formula='1 iff corresponding value is missing before training-only imputation'),
  fields=fields,tv_scopes=scopes,source_bindings=source_hashes,
  input_blockers=['H1','R1','R2','P1'],ready_for_build=False)
assert len(fields)==221 and len(set(result['model_order']))==442 and len(scopes)==13
target=root/'docs/specs/ETFE_FEATURE_MAP_20261003.json'
target.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
trials=old['trials']
assert len(trials)==21
exp=dict(schema='etfe-experiment-declaration-v1',status='declared_not_dataset_frozen',
  history_start='provider_global_verified_start_pending_H1',history_end_inclusive='2026-10-02',
  folds=[dict(id='2024h2',train_end='2024-06-30',validation_start='2024-07-01',validation_end='2024-12-31'),
         dict(id='2025h1',train_end='2024-12-31',validation_start='2025-01-01',validation_end='2025-06-30'),
         dict(id='2025h2',train_end='2025-06-30',validation_start='2025-07-01',validation_end='2025-12-31')],
  final_refit=dict(id='final',train_end='2025-12-31',test_start='2026-01-01',test_end='2026-10-02',all_21_required=True),
  embargo_sessions=10,purge='decision and final cash settlement horizon strictly before tenth preceding session open',
  targets=dict(win='float(P/A>0)',weighted_win='same win target; weight=clip(abs(P/A),.01,5)',return_huber='P/A'),
  feature_schema_sha256=sha(target),feature_count=442,
  trials=trials,required_fit_count=84,
  fit_ids=[f'{fold}/{t["id"]}' for fold in ('2024h2','2025h1','2025h2','final') for t in trials],
  gbt=dict(rounds=200,num_leaves=31,learning_rate=.05,min_data_in_leaf=20,max_bin=63,huber_alpha=.9,threads=1,subsampling=False),
  nn=dict(hidden=[64,32],activation='relu',optimizer='adam',learning_rate=.001,batch_size=4096,epochs=10,shuffle=False,dropout=0,huber_delta=1.),
  thresholds=dict(win=[.5,.55,.6],weighted_win=[.5,.55,.6],return_huber=[0,.01,.02]),
  selection='validation only; 100 completed positions, positive each fold, maxDD<=.20, excess>0 vs cash/best baseline; max mean fold excess, lower DD, lexical ID, lower threshold',
  acceptance=dict(min_test_completed_positions=100,max_drawdown=.20,positive_excess_vs_cash_and_best_baseline=True,positive_bootstrap_lower_95pct=True,
    bootstrap=dict(method='moving_block',replicates=2000,block_sessions=20,seed=20261003),
    required_stress=dict(cost_multiplier=2,lag_seconds=5,participation=.005,individually_and_combined=True)),
  calibration='none',trial_tuning='none',preprocessing='train-only medians; zero for naturally all-NaN columns; NN training mean/population std, masks unscaled',
  numerical_replay=dict(atol=1e-6,rtol=1e-5,exact_decisions=True),
  dataset_freeze_required=True,ready_for_training=False)
(root/'docs/specs/ETFE_EXPERIMENT_20261003.json').write_text(json.dumps(exp,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(fields=len(fields),tv_scopes=len(scopes),model_inputs=442,required_fits=84,source_files=len(source_hashes))))

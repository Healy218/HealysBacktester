import hashlib,json,zipfile
from collections import Counter
from pathlib import Path

ROOT=Path('/home/healy/Coding/HealysBacktester')
CACHE=ROOT/'nn_meta/data_cache_etfe'
REVIEW=ROOT/'docs/reviews/2026-10-04-etfe-demand-boundary'
KINDS=('discovery','boundary','surfaces')
sha=lambda data:hashlib.sha256(data).hexdigest()
raws={k:CACHE/f'alpaca-fresh-20261004-january-{k}-r0' for k in KINDS}
norms={k:CACHE/f'normalized-20261004-january-{k}-r0' for k in KINDS}
demand=ROOT/'nn_meta/validation/etfe-demand-20261004-r0'
inventory=json.loads((demand/'DEMAND.json').read_text())
summary={'schema':'etfe-demand-boundary-evidence-v1','date_central':'2026-10-04',
 'demand_sha256':inventory['sha256'],'calendar_demand':inventory['summary'],
 'raw':{},'normalized':{},'tests':{'command':'./venv/bin/python -m pytest tests/test_etfe_setup.py tests/test_etfe_vwap.py tests/test_etfe_pull_diagnosis.py tests/test_etfe_acquisition.py tests/test_etfe_purchase_policy.py tests/test_etfe_0dte.py tests/test_etfe_expansion.py tests/test_etfe_normalization.py tests/test_etfe_demand.py -q','passed':95},
 'full_demand_complete':False,'complete_history':False,'ready_for_build':False,'ready_for_training':False}
new_queries={sha(json.dumps([j['route'],j['params']],sort_keys=True,separators=(',',':'),allow_nan=False).encode())
             for j in json.loads((raws['discovery']/'PLAN.json').read_text())['jobs']}
captured={k for k,q in inventory['queries'].items() if q['disposition']=='captured'}|new_queries
summary['calendar_discovery_reconciliation']={'captured_queries':len(captured&inventory['queries'].keys()),
 'remaining_queries':len(inventory['queries'].keys()-captured),
 'january_padding_queries_outside_inventory':len(new_queries-inventory['queries'].keys())}
for k,r in raws.items():
 plan=json.loads((r/'PLAN.json').read_text());coverage=json.loads((r/'COVERAGE.json').read_text())
 runs=[json.loads(p.read_text()) for p in (r/'runs').glob('*.json')]
 statuses=Counter(str(json.loads(p.read_text())['status']) for p in (r/'attempts').glob('*/receipt.json'))
 summary['raw'][k]={'root':str(r.relative_to(ROOT)),'plan_sha256':plan['sha256'],
  'partitions':len(plan['jobs']),'rows':coverage['rows'],'symbols_observed':coverage['symbols_observed'],
  'by_ticker':coverage['by_ticker'],'statuses':dict(statuses),'invocations':len(runs),
  'active_seconds':sum(x['elapsed_seconds'] for x in runs),
  'requests':sum(x['requests_this_run'] for x in runs),
  'bytes':sum(p.stat().st_size for p in r.rglob('*') if p.is_file()),
  'absent_symbol_windows':sum(len(p['absent_symbols']) for p in coverage['partitions']),
  'reused_symbol_windows':len(plan['parent'].get('reused_symbol_windows',[]))}
 assert len(runs)<=4
 assert summary['raw'][k]['bytes']<512*2**20
for k,r in norms.items():
 seal=json.loads((r/'NORMALIZED.json').read_text());audit=json.loads((r/'INDEPENDENT_AUDIT.json').read_text())
 assert seal['normalized_complete'] and audit['raw_occurrence_sequence_preserved']
 assert seal['rows']==audit['rows']==summary['raw'][k]['rows']
 quality=Counter()
 for p in (r/'partitions').glob('*.json'):quality.update(json.loads(p.read_text())['quality_counts'])
 summary['normalized'][k]={'root':str(r.relative_to(ROOT)),'plan_sha256':seal['plan_sha256'],
  'rows':seal['rows'],'partitions':audit['partitions'],'quality_counts':dict(quality),
  'bytes':sum(p.stat().st_size for p in r.rglob('*') if p.is_file())}
summary['new_live_gets']=sum(r['statuses'].get('200',0) for r in summary['raw'].values())
summary['requests']=sum(r['requests'] for r in summary['raw'].values())
summary['active_capture_seconds']=sum(r['active_seconds'] for r in summary['raw'].values())
summary['new_rows']=sum(r['rows'] for r in summary['normalized'].values())
summary['new_partitions']=sum(r['partitions'] for r in summary['normalized'].values())
summary['surface_edge_audit']=json.loads((raws['surfaces']/'EDGE_AUDIT.json').read_text())
assert summary['requests']<=1536 and summary['active_capture_seconds']<3600
Path('/tmp/etfe-demand-summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
if not Path(str(REVIEW)+'.md').exists():
 print(json.dumps(summary,indent=2));raise SystemExit('Write review, then rerun to package')
members={};payload={}
for label,r in [('demand',demand)]+[(f'raw-{k}',v) for k,v in raws.items()]+[(f'normalized-{k}',v) for k,v in norms.items()]:
 for p in sorted(r.rglob('*')):
  if not p.is_file() or p.name=='writer.lock' or p.suffix=='.tmp':continue
  name=label+'/'+str(p.relative_to(r))
  if p.name=='body.json' or p.suffix=='.parquet':
   payload[name]={'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
  else:members[name]=p.read_bytes()
for p in [ROOT/'docs/specs/ETFE_DEMAND_CONTINUATION_20261004.md',Path(str(REVIEW)+'.md'),Path(__file__),Path('/tmp/audit_etfe_january_edges.py')]:
 members['review-source/'+p.name]=p.read_bytes()
members['OBSERVATIONS.json']=(json.dumps(summary,indent=2,sort_keys=True)+'\n').encode()
members['PAYLOAD_INDEX.json']=(json.dumps(payload,indent=2,sort_keys=True)+'\n').encode()
manifest={n:sha(b) for n,b in sorted(members.items())}
members['MANIFEST.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
bundle=Path(str(REVIEW)+'-evidence.zip')
with zipfile.ZipFile(bundle,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
summary['evidence_bundle']={'path':str(bundle.relative_to(ROOT)),'bytes':bundle.stat().st_size,
 'sha256':sha(bundle.read_bytes()),'members':len(members),'indexed_payload_files':len(payload),
 'contents':'metadata/source/report bundle; raw bodies and Parquet remain local and are hash-indexed'}
summary['source_files']={n:sha((ROOT/n).read_bytes()) for n in [
 'nn_meta/etfe/demand.py','scripts/etfe_demand.py','tests/test_etfe_demand.py',
 'docs/specs/ETFE_DEMAND_20261004.md','docs/specs/ETFE_DEMAND_CONTINUATION_20261004.md',
 'docs/reviews/2026-10-04-etfe-demand-boundary.md']}
Path(str(REVIEW)+'.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:summary[k] for k in ['new_live_gets','active_capture_seconds','new_rows','new_partitions','evidence_bundle']},indent=2))

import json
from collections import Counter
from datetime import date
from pathlib import Path
import sys
ROOT=Path('/home/healy/Coding/HealysBacktester');sys.path.insert(0,str(ROOT))
from nn_meta.etfe.acquisition import committed,iter_records,load_plan,save,sha
from nn_meta.etfe.demand import returned_contracts
from scripts.acquire_etfe_alpaca import interval
base=ROOT/'nn_meta/data_cache_etfe'
roots=[base/n for n in ['alpaca-fresh-20261003-bootstrap-r0','alpaca-fresh-20261004-options-r0',
                        'alpaca-fresh-20261004-january-discovery-r0']]
_,contracts,_=returned_contracts(roots)
root=base/'alpaca-fresh-20261004-january-surfaces-r0';plan=load_plan(root)
expected={(s,d) for s,c in contracts.items() for d in ('2024-01-18','2024-01-19')
          if 0<=(date.fromisoformat(c['expiry'])-date.fromisoformat(d)).days<=45}
edges=plan['parent']['symbol_window_edges']
actual=[(e['symbol'],e['day']) for e in edges]
assert len(set(actual))==len(actual) and set(actual)==expected
jobs={j['id']:j for j in plan['jobs']}
physical={};counts={};row_total=0
for j in jobs.values():
 assert committed(root,j)[2]
 c=Counter(r['symbol'] for r in iter_records(root,j));counts[j['id']]=c
 for s in j['params']['symbols'].split(','):
  key=(s,j['params']['start']);assert key not in physical;physical[key]=j['id']
 row_total+=sum(c.values())
reuse_cache={};seen_fresh=set();totals=Counter();by_day={}
for e in edges:
 symbol,day=e['symbol'],e['day'];expiry=contracts[symbol]['expiry']
 dte=(date.fromisoformat(expiry)-date.fromisoformat(day)).days
 assert e['purposes']==(['purchase_discovery'] if dte<=5 else [])+(['daily_context'] if dte>=1 else [])
 end='2024-01-19' if day=='2024-01-18' else '2024-01-20';window=interval(day,end)
 if e['capture'] is None:
  j=jobs[e['job_id']];assert physical[(symbol,window['start'])]==j['id']
  assert all(j['params'][k]==v for k,v in window.items())
  seen_fresh.add((symbol,window['start']));n=counts[j['id']][symbol];totals['new_rows']+=n
 else:
  cap=e['capture'];key=(cap['root'],cap['job_id'])
  if key not in reuse_cache:
   p=load_plan(cap['root']);assert p['sha256']==cap['plan_sha256']
   j=next(j for j in p['jobs'] if j['id']==cap['job_id']);assert committed(cap['root'],j)[2]
   assert j==cap['item'];reuse_cache[key]=(j,Counter(r['symbol'] for r in iter_records(cap['root'],j)))
  j,c=reuse_cache[key];assert symbol in j['params']['symbols'].split(',')
  assert all(j['params'][k]==v for k,v in window.items())
  n=c[symbol];totals['reused_rows']+=n;totals['reused_symbol_windows']+=1
 totals['observed_symbol_windows' if n else 'absent_symbol_windows']+=1
 key=day+'/'+e['ticker'];by_day.setdefault(key,Counter())
 by_day[key]['expected_symbol_windows']+=1;by_day[key]['rows']+=n
 by_day[key]['observed_symbol_windows' if n else 'absent_symbol_windows']+=1
assert seen_fresh==set(physical)
assert totals['new_rows']==row_total
assert totals['observed_symbol_windows']+totals['absent_symbol_windows']==len(expected)
report=dict(schema='etfe-surface-edge-audit-v1',plan_sha256=plan['sha256'],
 expected_symbol_windows=len(expected),totals=dict(totals),by_ticker_day={k:dict(v) for k,v in sorted(by_day.items())},
 all_physical_jobs_and_reuse_links_reconciled=True,
 historical_listings_complete=False,absence='unresolved_not_no_trade',ready_for_build=False,
 audit_source_sha256=sha(Path(__file__).read_bytes()))
save(root/'EDGE_AUDIT.json',report)
print(json.dumps(report,indent=2))
